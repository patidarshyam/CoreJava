package enumusedemo;

import enumusedemo.enumerator.Color;

public class EnumDemo {
	public static void main(String[] args) {
		Color color=Color.RED;
		//Color newColor=Color.WHITE;
		System.out.println(color.ordinal());
		System.out.println(color.values());
		
	
	}
}
