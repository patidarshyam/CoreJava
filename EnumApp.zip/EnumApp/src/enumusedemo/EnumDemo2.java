package enumusedemo;

import enumusedemo.enumerator.Color;
import enumusedemo.enumerator.Currency;

public class EnumDemo2 {
	public static void main(String[] args) {
		Currency c= Currency.QUARTER;
		
		System.out.println(c);
		
	
	}
}
