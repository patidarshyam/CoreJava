package enumusedemo;

import enumusedemo.enumerator.Color;
import enumusedemo.enumerator.ProjectType;

public class EnumDemo3 {
	public static void main(String[] args) {
		ProjectType p=ProjectType.JAVA;
		ProjectType p1=p.DOTNET;
		System.out.println(p+" "+p1);
		
	
	}
}
