package enumusedemo;

import enumusedemo.enumerator.Operation;

public class OperationDemo {
	public static void main(String[] args) {
		Operation operation=Operation.PLUS;
		System.out.println(operation.calculate(operation.TIMES, 120, 11));
		
	}

}
