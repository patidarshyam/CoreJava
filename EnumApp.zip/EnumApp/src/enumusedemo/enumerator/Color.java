package enumusedemo.enumerator;

public enum Color {
	RED,GREEN,BLUE
	
};

