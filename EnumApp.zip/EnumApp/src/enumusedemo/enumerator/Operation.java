package enumusedemo.enumerator;

public enum Operation {
PLUS("+") {
	@Override
	public double apply(double x1, double x2) {
		return x1+x2;
	}
},
MINUS("-") {
	@Override
	public double apply(double x1, double x2) {
		return x1-x2;
	}
},
TIMES("*") {
	@Override
	public double apply(double x1, double x2) {
		return x1*x2;
	}
},
DIVID("/") {
	@Override
	public double apply(double x1, double x2) {
		return x1/x2;
	}
};
	
	 private final String text;

	    private Operation(String text) {
	        this.text = text;
	    }
	    public abstract double apply(double x1, double x2);


		@Override 
	    public String toString() {
	        return text;
	    }
		public String calculate(Operation op, double x1, double x2)
		{
		    return String.valueOf(op.apply(x1, x2));
		}
			
	 }
