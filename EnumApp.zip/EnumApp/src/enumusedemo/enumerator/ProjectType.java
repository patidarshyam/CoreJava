package enumusedemo.enumerator;

public enum ProjectType {
	JAVA("web application"),
	PHP("web application"),
	DOTNET("web application");
	
	private String string;

	private ProjectType(String string) {
		this.string=string;
	}
	
	@Override
	public String toString() {
		switch (this) {
		case JAVA: return "JAVA : "+string;
		case PHP: return "PHP : "+string;		
		case DOTNET: return "DOTNET : "+string;
		default:
			return super.toString();
		}
	}
};
