package com.yash.consecutivenumber;

public class Consecutive {

	public Integer calculateSum(Integer input) {
		if(input==null){
			return null;
		}
		else{ if(input<2147483647){ 
		int sum=5*((2*input)+9);
		System.out.println(sum);
		return sum;
		}
		else{
			return null;}
		}

	}

}
	
