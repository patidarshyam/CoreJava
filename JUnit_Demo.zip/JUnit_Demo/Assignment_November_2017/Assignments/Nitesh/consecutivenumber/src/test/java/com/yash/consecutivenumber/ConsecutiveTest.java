package com.yash.consecutivenumber;

import org.junit.Test;

import junit.framework.TestCase;

public class ConsecutiveTest extends TestCase {
	@Test
	public void test_for_single_digit_as_empty(){
		Consecutive consecutive=new Consecutive();
		Integer sum=consecutive.calculateSum(null);
		//System.out.print(VALUE_AS_INPUT);
		assertEquals(null,sum);
	}
	
	public void test_for_single_digit_as_possitive(){
		Consecutive consecutive=new Consecutive();
		Integer sum=consecutive.calculateSum(new Integer(1));
		assertEquals(new Integer(55),sum);
	}

	@Test
	public void test_for_single_digit_as_negative(){
		Consecutive consecutive=new Consecutive();
		Integer sum=consecutive.calculateSum(new Integer(-4));
		assertEquals(new Integer(5),sum);
	}
	
	@Test
	public void test_for_single_digit_for_any(){
		Consecutive consecutive=new Consecutive();
		Integer sum=consecutive.calculateSum(new Integer(0));
		assertEquals(new Integer(45),sum);
	}

	@Test
	public void test_for_maximum_range_upto_10_digit(){
		Consecutive consecutive=new Consecutive();
		Integer sum=consecutive.calculateSum(new Integer(1000555555));
		assertEquals(new Integer(1415621003),sum);
	}
		
	

}
