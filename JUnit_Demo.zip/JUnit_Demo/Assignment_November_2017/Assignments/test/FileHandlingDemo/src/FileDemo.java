import java.io.File;
import java.io.IOException;

public class FileDemo {

	public static void main(String[] args) {
		File file=new File("test","testdemofile.txt");
		System.out.println(file.toString());
		System.out.println(file.exists());
		boolean create=false;
		try {
			//create=file.createNewFile();
			//create=file.mkdir();
			create=file.createNewFile();
			System.out.println(create);
			System.out.println("File check : - "+file.isFile());
			System.out.println("Directory Check : -"+file.isDirectory());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
