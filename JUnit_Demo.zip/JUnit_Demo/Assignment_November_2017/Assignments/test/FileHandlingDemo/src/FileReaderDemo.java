import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderDemo {

	public static void main(String[] args) {
		File file=new File("test.txt");
		char buf[]=new char[100];
		try {
			FileReader fr=new FileReader(file);
			try {
				fr.read(buf);
				for (char c : buf) {
					System.out.print(c);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
