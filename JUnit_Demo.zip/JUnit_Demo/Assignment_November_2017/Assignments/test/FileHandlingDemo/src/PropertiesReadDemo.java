import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropertiesReadDemo {

	public static void main(String[] args) {
		Properties prop=new Properties();
		FileInputStream input=null;
		try {
			input=new FileInputStream("dbconfig.properties");
			try {
				prop.load(input);
				System.out.println("Driver class name : -"+prop.getProperty("driverClassName"));
				System.out.println("URL : -"+prop.getProperty("url"));
				System.out.println("Username : -"+prop.getProperty("username"));
				System.out.println("Password : -"+prop.getProperty("password"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			try {
				input.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
