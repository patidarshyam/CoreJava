import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesWriteDemo {

	public static void main(String[] args) {
		Properties prop=new Properties();
		FileOutputStream output=null;
		try {
			output=new FileOutputStream("dbconfig.properties");
			prop.setProperty("driverClassName", "com.mysql.jdbc.Driver");
			prop.setProperty("url", "localhost:/mydb");
			prop.setProperty("username", "root");
			prop.setProperty("password", "root");
			
			//save data in input file
			prop.save(output, null);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		finally {
			if(output!=null){
				try {
					output.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}

}
