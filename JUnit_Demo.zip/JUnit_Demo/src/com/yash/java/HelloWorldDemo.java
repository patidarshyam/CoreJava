package com.yash.java;

public class HelloWorldDemo {
	public String sayHello(){
		return "Hello";
	}
}
