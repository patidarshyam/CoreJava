package com.yash.controller;

import com.yash.pojo.Application;
import com.yash.pojoi.Pojo;

public class ApplicationController implements Pojo {
	public ApplicationController() {
		System.out.println("appCtrl object created");
	}

}
