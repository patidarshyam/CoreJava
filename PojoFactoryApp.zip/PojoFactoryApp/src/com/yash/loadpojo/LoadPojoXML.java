package com.yash.loadpojo;

import java.io.File;

import com.yash.pojofactory.PojoFactory;

public class LoadPojoXML extends PojoFactory {
	public LoadPojoXML(File xmlFile) {
		super(xmlFile);
	}

}
