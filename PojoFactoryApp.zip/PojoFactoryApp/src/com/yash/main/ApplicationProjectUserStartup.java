package com.yash.main;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

import com.yash.controller.ApplicationController;
import com.yash.loadpojo.LoadPojoXML;
import com.yash.myException.NotRegisteredInApplicationOrXML;
import com.yash.pojo.Application;
import com.yash.pojo.Project;
import com.yash.pojo.User;
import com.yash.pojofactory.PojoFactory;
import com.yash.service.ApplicationService;
  
public class ApplicationProjectUserStartup {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		PojoFactory pojoFactory= new LoadPojoXML( new File("pojosProjectUser.xml"));
		try {
			Application application = (Application) pojoFactory.getPojo("application");
			Project project=(Project)pojoFactory.getPojo("project");
			User user = (User) pojoFactory.getPojo("user");
			
			
			application.getDetails();
			user.getDetails();
			project.getDetails();
			
			if(application==null || user==null || project==null) throw new NotRegisteredInApplicationOrXML("not......");
		} catch (NotRegisteredInApplicationOrXML e) {
			e.printStackTrace();
		}
	}
}
