package com.yash.main;

import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;

import com.yash.controller.ApplicationController;
import com.yash.loadpojo.LoadPojoXML;
import com.yash.myException.NotRegisteredInApplicationOrXML;
import com.yash.pojo.Application;
import com.yash.pojofactory.PojoFactory;
import com.yash.service.ApplicationService;

public class ApplicationStartup {

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, ClassNotFoundException, InstantiationException, IllegalAccessException {
		PojoFactory pojoFactory= new LoadPojoXML( new File("pojosDoc.xml"));
		try {
			Application appObj = (Application) pojoFactory.getPojo("application");
			//ApplicationController obj=(ApplicationController)pojoFactory.getPojo("appCtrl");
			//ApplicationService obj = (ApplicationService) pojoFactory.getPojo("appService");
			
			appObj.getDetails();
			
			if(appObj==null) throw new NotRegisteredInApplicationOrXML("not......");
		} catch (NotRegisteredInApplicationOrXML e) {
			e.printStackTrace();
		}
	}
}
