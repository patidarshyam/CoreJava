package com.yash.myException;

public class NotRegisteredInApplicationOrXML extends Exception{
	public NotRegisteredInApplicationOrXML(String errMsg) {
		super(errMsg);
	}
}
