package com.yash.pojo;

import com.yash.pojoi.Pojo;

public class Application implements Pojo{
	
	private int id;
	private String title;
	private int duration;
	
	public Application() {
		System.out.println("Application Object Created");
	}
	
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}

	public void getDetails() {
		System.out.println("Details are :- ");
		System.out.println("Id : "+this.getId()+" ,Title : "+this.getTitle()+" ,Duration : "+this.getDuration());
	}
}
