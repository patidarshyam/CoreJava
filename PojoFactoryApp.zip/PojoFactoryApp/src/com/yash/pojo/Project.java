package com.yash.pojo;

import com.yash.pojoi.Pojo;

public class Project implements Pojo {
	private int projectId;
	private String projcetName;
	
	public Project() {
		
	}
	public int getProjectId() {
		return projectId;
	}
	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}
	public String getProjcetName() {
		return projcetName;
	}
	public void setProjcetName(String projcetName) {
		this.projcetName = projcetName;
	}
	
	public void getDetails() {
		System.out.println("Details are :- ");
		System.out.println("Project Id : "+this.getProjectId()+" ,Project Name : "+this.getProjcetName());
	}

}
