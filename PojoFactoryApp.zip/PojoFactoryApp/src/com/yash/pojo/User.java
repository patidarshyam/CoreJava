package com.yash.pojo;

import com.yash.pojoi.Pojo;

public class User implements Pojo{
	private int userId;
	private String userName;
	public User() {
		
	}
	
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public void getDetails() {
		System.out.println("Details are :- ");
		System.out.println("User Id : "+this.getUserId()+" ,User Name : "+this.getUserName());
	}
}
