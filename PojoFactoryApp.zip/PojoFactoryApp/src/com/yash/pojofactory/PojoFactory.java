package com.yash.pojofactory;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;

import javax.xml.parsers.*;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

import com.yash.myException.NotRegisteredInApplicationOrXML;
import com.yash.pojo.Application;
import com.yash.pojo.Project;
import com.yash.pojo.User;
import com.yash.pojoi.Pojo;

public class PojoFactory implements Pojo{
	private File xmlFile;
	public PojoFactory(File xmlFile) {
		this.xmlFile=xmlFile;
	}

	public Object getPojo(String pojo) throws ParserConfigurationException, SAXException, IOException, InstantiationException, IllegalAccessException, NotRegisteredInApplicationOrXML, ClassNotFoundException{
		Object object = null;
		
		DocumentBuilderFactory dbFactory=DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder= dbFactory.newDocumentBuilder();
		Document doc=dBuilder.parse(xmlFile);
		doc.getDocumentElement().normalize();
	
		NodeList nl=doc.getElementsByTagName("pojo");
		for(int i=0;i<nl.getLength();i++){
		Node node=nl.item(i);
		Element element=(Element) node;
		String id=element.getAttribute("id");
		if(id.equals(pojo)){

			String className=element.getAttribute("class");
			Class c= Class.forName(className);
			
//			//below
//			Field []fields=c.getDeclaredFields();
//			for (Field field : fields) {
//				field.setAccessible(true);
//			}
//			NodeList appList=element.getElementsByTagName("property");
//			for(int count=0;count<appList.getLength();count++){
//				Node newNode= appList.item(count);
//				Element app=(Element) newNode;
//			
//					String newValue=app.getAttribute("value");
//					//int intID=Integer.parseInt(newValue);
//					fields[count].set(c, newValue);
//				}
//				}
//			//above
			
			object=c.newInstance();//object created	
//			System.out.println(object);
			if(object instanceof Application){
				NodeList appList=element.getElementsByTagName("property");
				for(int count=0;count<appList.getLength();count++){
					Node newNode= appList.item(count);
					Element app=(Element) newNode;
					
					if(app.getAttribute("name").equals("id")){
						String name=app.getAttribute("value");
						int intID=Integer.parseInt(name);
						((Application) object).setId(intID);
						//System.out.println("id :"+intID);
					}else if(app.getAttribute("name").equals("title")){
						String stringTitle=app.getAttribute("value");
						((Application) object).setTitle(stringTitle);
					//	System.out.println("title : "+stringTitle);
					}else if(app.getAttribute("name").equals("duration")){
						String name=app.getAttribute("value");
						int intDuration=Integer.parseInt(name);
						((Application) object).setDuration(intDuration);
						//System.out.println("duration : "+intDuration);
					}
				}
			}
			if(object instanceof Project){
				NodeList appList=element.getElementsByTagName("property");
				for(int count=0;count<appList.getLength();count++){
					Node newNode= appList.item(count);
					Element app=(Element) newNode;
					
					if(app.getAttribute("name").equals("projectId")){
						String name=app.getAttribute("value");
						int intID=Integer.parseInt(name);
						((Project) object).setProjectId(intID);
						System.out.println("id :"+intID);
					}else if(app.getAttribute("name").equals("projectName")){
						String stringTitle=app.getAttribute("value");
						((Project) object).setProjcetName(stringTitle);
					//	System.out.println("title : "+stringTitle);
					}
				}
			}
			if(object instanceof User){
				NodeList appList=element.getElementsByTagName("property");
				for(int count=0;count<appList.getLength();count++){
					Node newNode= appList.item(count);
					Element app=(Element) newNode;
					
					if(app.getAttribute("name").equals("userId")){
						String name=app.getAttribute("value");
						int intID=Integer.parseInt(name);
						((User) object).setUserId(intID);
						//System.out.println("id :"+intID);
					}else if(app.getAttribute("name").equals("userName")){
						String stringTitle=app.getAttribute("value");
						((User) object).setUserName(stringTitle);
					//	System.out.println("title : "+stringTitle);
					}
				}
			}
			return object;
			}
		}
		
		return object;
	}
}
