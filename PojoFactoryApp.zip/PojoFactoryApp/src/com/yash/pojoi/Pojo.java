package com.yash.pojoi;

public interface Pojo {

}
