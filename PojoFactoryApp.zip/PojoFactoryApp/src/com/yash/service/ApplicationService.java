package com.yash.service;

import com.yash.pojoi.Pojo;

public class ApplicationService implements Pojo {
	public ApplicationService() {
	System.out.println("Application service object created");
	}
}
